<?php
session_start();
include("../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Access Denied");
}

// STATS

// Total Students
$students = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) as total FROM users WHERE role='student'
"))['total'];

// Total Teachers
$teachers = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) as total FROM users WHERE role='teacher'
"))['total'];

// Total Exams
$exams = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) as total FROM exams
"))['total'];

// Total Results
$results = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) as total FROM results
"))['total'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- ICONS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

body {
    background: linear-gradient(135deg, #1d2b64, #f8cdda);
    min-height: 100vh;
    color: white;
    font-family: 'Segoe UI', sans-serif;
}

.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 25px;
    text-align: center;
    transition: 0.3s;
}

.glass:hover {
    transform: translateY(-8px);
}

.btn-custom {
    border-radius: 25px;
    padding: 10px 20px;
}

</style>
</head>

<body>

<div class="container py-4">

    <h2 class="mb-4">🧑‍💼 Admin Dashboard</h2>

    <!-- STATS -->
    <div class="row">

        <div class="col-md-3 mb-3">
            <div class="glass shadow">
                <h3><i class="fa-solid fa-user-graduate"></i></h3>
                <h2><?php echo $students; ?></h2>
                <p>Students</p>
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <div class="glass shadow">
                <h3><i class="fa-solid fa-chalkboard-teacher"></i></h3>
                <h2><?php echo $teachers; ?></h2>
                <p>Teachers</p>
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <div class="glass shadow">
                <h3><i class="fa-solid fa-book"></i></h3>
                <h2><?php echo $exams; ?></h2>
                <p>Exams</p>
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <div class="glass shadow">
                <h3><i class="fa-solid fa-chart-line"></i></h3>
                <h2><?php echo $results; ?></h2>
                <p>Results</p>
            </div>
        </div>

    </div>

    <!-- ACTIONS -->
    <div class="glass mt-4 shadow text-center">

        <h4 class="mb-3">⚡ Quick Actions</h4>

        <!-- ✅ CORRECT PATHS (YOUR STRUCTURE BASED) -->

        <a href="students/view_students.php" class="btn btn-primary btn-custom m-2">
            <i class="fa-solid fa-users"></i> Manage Students
        </a>

        <a href="teachers/view_teachers.php" class="btn btn-success btn-custom m-2">
            <i class="fa-solid fa-user-tie"></i> Manage Teachers
        </a>

        <a href="subjects/view_subjects.php" class="btn btn-warning btn-custom m-2">
            <i class="fa-solid fa-book"></i> Subjects
        </a>
        <a href="reports/dashboard.php" class="btn btn-dark">
    📊 Reports
</a>

        <a href="exams/view_exams.php" class="btn btn-info btn-custom m-2">
            <i class="fa-solid fa-list"></i> Exams
        </a>

        <a href="results/view_results.php" class="btn btn-dark btn-custom m-2">
            <i class="fa-solid fa-chart-bar"></i> Results
        </a>

        <a href="../logout.php" class="btn btn-danger btn-custom m-2">
            <i class="fa-solid fa-sign-out-alt"></i> Logout
        </a>

    </div>

</div>

</body>
</html>