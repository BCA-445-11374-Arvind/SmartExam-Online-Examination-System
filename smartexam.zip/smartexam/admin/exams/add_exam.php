<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Access Denied");
}

// FETCH SUBJECTS
$subjects = $conn->query("SELECT * FROM subjects");

// ADD EXAM
if(isset($_POST['add_exam'])){
    $title = $_POST['title'];
    $subject_id = $_POST['subject_id'];
    $date = $_POST['date'];
    $duration = $_POST['duration'];

    $stmt = $conn->prepare("INSERT INTO exams (title, subject_id, date, duration) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sisi", $title, $subject_id, $date, $duration);

    if($stmt->execute()){
        $success = "Exam Created Successfully ✅";
    } else {
        $error = "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Exam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-5">

    <div class="card shadow">
        <div class="card-header text-center bg-warning">
            <h4>Create Exam</h4>
        </div>

        <div class="card-body">

            <?php if(isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
            <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

            <form method="POST">

                <div class="mb-3">
                    <label class="form-label">Exam Title</label>
                    <input type="text" name="title" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Subject</label>
                    <select name="subject_id" class="form-control" required>
                        <option value="">Select Subject</option>
                        <?php
                        while($row = $subjects->fetch_assoc()){
                            echo "<option value='".$row['id']."'>".$row['subject_name']."</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Date & Time</label>
                    <input type="datetime-local" name="date" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Duration (minutes)</label>
                    <input type="number" name="duration" class="form-control" required>
                </div>

                <button type="submit" name="add_exam" class="btn btn-warning w-100">Create Exam</button>

            </form>

        </div>
    </div>

    <div class="text-center mt-3">
        <a href="../dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>

</div>

</body>
</html>