<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Access Denied");
}

// FETCH EXAMS
$exams = $conn->query("SELECT * FROM exams");

// FETCH QUESTIONS
$questions = $conn->query("SELECT * FROM question_bank");

// ASSIGN
if(isset($_POST['assign'])){
    $exam_id = $_POST['exam_id'];
    $question_ids = $_POST['questions'];

    foreach($question_ids as $qid){
        $stmt = $conn->prepare("INSERT INTO exam_questions (exam_id, question_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $exam_id, $qid);
        $stmt->execute();
    }

    $success = "Questions Assigned Successfully ✅";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assign Questions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-4">

    <div class="card shadow">
        <div class="card-header text-center bg-info text-white">
            <h4>Assign Questions to Exam</h4>
        </div>

        <div class="card-body">

            <?php if(isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>

            <form method="POST">

                <div class="mb-3">
                    <label class="form-label">Select Exam</label>
                    <select name="exam_id" class="form-control" required>
                        <option value="">Select Exam</option>
                        <?php
                        while($e = $exams->fetch_assoc()){
                            echo "<option value='".$e['id']."'>".$e['title']."</option>";
                        }
                        ?>
                    </select>
                </div>

                <label class="form-label">Select Questions</label>

                <div class="border p-3" style="max-height:300px; overflow-y:auto;">
                    <?php
                    while($q = $questions->fetch_assoc()){
                        echo "
                        <div class='form-check'>
                            <input class='form-check-input' type='checkbox' name='questions[]' value='".$q['id']."'>
                            <label class='form-check-label'>
                                ".$q['question']."
                            </label>
                        </div>";
                    }
                    ?>
                </div>

                <br>

                <button type="submit" name="assign" class="btn btn-info w-100">Assign Questions</button>

            </form>

        </div>
    </div>

    <div class="text-center mt-3">
        <a href="../dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
    </div>

</div>

</body>
</html>