<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Access Denied");
}

// DELETE EXAM
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM exams WHERE id='$id'");
    header("Location: view_exams.php");
    exit();
}

// FETCH EXAMS
$query = "
SELECT e.*, s.subject_name, u.name as teacher_name 
FROM exams e
JOIN subjects s ON e.subject_id = s.id
JOIN users u ON e.teacher_id = u.id
ORDER BY e.id DESC
";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Exams</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- ICONS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

body {
    background: linear-gradient(135deg, #1d2b64, #f8cdda);
    min-height: 100vh;
    color: white;
    font-family: 'Segoe UI', sans-serif;
}

/* GLASS */
.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
}

/* TABLE */
.table {
    color: white;
}

.table thead {
    background: rgba(0,0,0,0.4);
}

.table tbody tr:hover {
    background: rgba(255,255,255,0.1);
}

/* BUTTON */
.btn-custom {
    border-radius: 25px;
    padding: 5px 12px;
}

.badge {
    padding: 6px 12px;
}

</style>
</head>

<body>

<div class="container py-4">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>📝 Manage Exams</h2>

        <a href="../dashboard.php" class="btn btn-light">
            ⬅ Back to Dashboard
        </a>
    </div>

    <!-- TABLE -->
    <div class="glass shadow">

        <table class="table table-bordered text-center align-middle">

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Subject</th>
                    <th>Teacher</th>
                    <th>Duration</th>
                    <th>Total Marks</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

            <?php 
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
            ?>

                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['title']; ?></td>
                    <td><?php echo $row['subject_name']; ?></td>
                    <td><?php echo $row['teacher_name']; ?></td>
                    <td><?php echo $row['duration']; ?> min</td>
                    <td><?php echo $row['total_marks']; ?></td>

                    <td>
                        <?php if($row['status'] == 'active'){ ?>
                            <span class="badge bg-success">Active</span>
                        <?php } else { ?>
                            <span class="badge bg-secondary">Inactive</span>
                        <?php } ?>
                    </td>

                    <td>
                        <a href="?delete=<?php echo $row['id']; ?>" 
                           class="btn btn-danger btn-custom"
                           onclick="return confirm('Delete this exam?');">
                           <i class="fa-solid fa-trash"></i> Delete
                        </a>
                    </td>

                </tr>

            <?php 
                }
            } else {
                echo "<tr><td colspan='8'>No Exams Found ❌</td></tr>";
            }
            ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>