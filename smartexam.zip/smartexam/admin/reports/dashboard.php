<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Access Denied");
}

// TOTAL COUNTS
$students = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE role='student'"))['total'];

$teachers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE role='teacher'"))['total'];

$exams = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM exams"))['total'];

$attempts = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM results"))['total'];

// TOP STUDENT
$top = mysqli_query($conn, "
SELECT u.name, MAX(r.score) as score
FROM results r
JOIN users u ON r.student_id = u.id
GROUP BY r.student_id
ORDER BY score DESC
LIMIT 1
");
$top_student = mysqli_fetch_assoc($top);

// RECENT RESULTS
$recent = mysqli_query($conn, "
SELECT u.name, e.title, r.score
FROM results r
JOIN users u ON r.student_id = u.id
JOIN exams e ON r.exam_id = e.id
ORDER BY r.id DESC
LIMIT 5
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Reports</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(135deg, #1d2b64, #f8cdda);
    color: white;
}
.card {
    border-radius: 15px;
}
</style>

</head>

<body>

<div class="container mt-4">

<div class="d-flex justify-content-between mb-4">
    <h2>📊 Admin Report Dashboard</h2>
    <a href="../dashboard.php" class="btn btn-light">⬅ Back</a>
</div>

<!-- STATS -->
<div class="row text-center">

<div class="col-md-3 mb-3">
<div class="card p-3 shadow">
<h4><?php echo $students; ?></h4>
<p>Students</p>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card p-3 shadow">
<h4><?php echo $teachers; ?></h4>
<p>Teachers</p>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card p-3 shadow">
<h4><?php echo $exams; ?></h4>
<p>Exams</p>
</div>
</div>

<div class="col-md-3 mb-3">
<div class="card p-3 shadow">
<h4><?php echo $attempts; ?></h4>
<p>Attempts</p>
</div>
</div>

</div>

<!-- TOP STUDENT -->
<div class="card p-3 shadow mb-4">
<h4>🏆 Top Performer</h4>

<?php if($top_student){ ?>
<p><b><?php echo $top_student['name']; ?></b> - Score: <?php echo $top_student['score']; ?></p>
<?php } else { ?>
<p>No data available</p>
<?php } ?>

</div>

<!-- RECENT RESULTS -->
<div class="card p-3 shadow">

<h4>🕒 Recent Results</h4>

<table class="table table-bordered text-center mt-3">

<thead class="table-dark">
<tr>
<th>Student</th>
<th>Exam</th>
<th>Score</th>
</tr>
</thead>

<tbody>

<?php 
if(mysqli_num_rows($recent) > 0){
while($row = mysqli_fetch_assoc($recent)){
?>

<tr>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['title']; ?></td>
<td><?php echo $row['score']; ?></td>
</tr>

<?php } } else { ?>
<tr><td colspan="3">No Results Found ❌</td></tr>
<?php } ?>

</tbody>

</table>

</div>

</div>

</body>
</html>