<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Access Denied");
}

// FETCH RESULTS
$stmt = $conn->prepare("
    SELECT r.score, u.name AS student_name, e.title AS exam_title
    FROM results r
    JOIN users u ON r.student_id = u.id
    JOIN exams e ON r.exam_id = e.id
");
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Results</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-4">

    <div class="d-flex justify-content-between mb-3">
        <h3>All Results</h3>
        <a href="../dashboard.php" class="btn btn-secondary">Back</a>
    </div>

    <div class="card shadow">
        <div class="card-body">

            <table class="table table-bordered table-hover text-center">
                <thead class="table-dark">
                    <tr>
                        <th>Student</th>
                        <th>Exam</th>
                        <th>Score</th>
                    </tr>
                </thead>

                <tbody>
                <?php
                if($result->num_rows > 0){
                    while($row = $result->fetch_assoc()){
                        echo "<tr>
                            <td>".$row['student_name']."</td>
                            <td>".$row['exam_title']."</td>
                            <td>".$row['score']."</td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>No Results Found</td></tr>";
                }
                ?>
                </tbody>

            </table>

        </div>
    </div>

</div>

</body>
</html>