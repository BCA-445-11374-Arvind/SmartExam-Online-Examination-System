<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Access Denied");
}

// FETCH STUDENTS
$query = "SELECT * FROM users WHERE role='student' ORDER BY id DESC";
$result = mysqli_query($conn, $query);

// BLOCK / UNBLOCK
if(isset($_GET['action']) && isset($_GET['id'])){
    $id = $_GET['id'];

    if($_GET['action'] == 'block'){
        mysqli_query($conn, "UPDATE users SET status='blocked' WHERE id='$id'");
    } elseif($_GET['action'] == 'unblock'){
        mysqli_query($conn, "UPDATE users SET status='active' WHERE id='$id'");
    }

    header("Location: view_students.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Students</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- ICONS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

body {
    background: linear-gradient(135deg, #1d2b64, #f8cdda);
    min-height: 100vh;
    color: white;
    font-family: 'Segoe UI', sans-serif;
}

/* GLASS */
.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
}

/* TABLE */
.table {
    color: white;
}

.table thead {
    background: rgba(0,0,0,0.4);
}

.table tbody tr:hover {
    background: rgba(255,255,255,0.1);
}

/* BUTTON */
.btn-custom {
    border-radius: 25px;
    padding: 5px 12px;
}

.badge {
    padding: 6px 12px;
}

</style>
</head>

<body>

<div class="container py-4">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>👨‍🎓 Manage Students</h2>

        <a href="../dashboard.php" class="btn btn-light">
            ⬅ Back to Dashboard
        </a>
    </div>

    <!-- TABLE -->
    <div class="glass shadow">

        <table class="table table-bordered text-center align-middle">

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

            <?php 
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
            ?>

                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['email']; ?></td>

                    <td>
                        <?php if($row['status'] == 'active'){ ?>
                            <span class="badge bg-success">Active</span>
                        <?php } else { ?>
                            <span class="badge bg-danger">Blocked</span>
                        <?php } ?>
                    </td>

                    <td>
                        <?php if($row['status'] == 'active'){ ?>
                            <a href="?action=block&id=<?php echo $row['id']; ?>" 
                               class="btn btn-danger btn-custom">
                               Block
                            </a>
                        <?php } else { ?>
                            <a href="?action=unblock&id=<?php echo $row['id']; ?>" 
                               class="btn btn-success btn-custom">
                               Unblock
                            </a>
                        <?php } ?>
                    </td>

                </tr>

            <?php 
                }
            } else {
                echo "<tr><td colspan='5'>No Students Found ❌</td></tr>";
            }
            ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>