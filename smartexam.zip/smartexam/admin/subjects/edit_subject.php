<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Access Denied");
}

// VALIDATE ID
if(!isset($_GET['id'])){
    die("Invalid Request");
}

$id = $_GET['id'];

// FETCH DATA
$stmt = $conn->prepare("SELECT subject_name FROM subjects WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

// UPDATE SUBJECT
if(isset($_POST['update'])){
    $subject_name = $_POST['subject_name'];

    $stmt = $conn->prepare("UPDATE subjects SET subject_name=? WHERE id=?");
    $stmt->bind_param("si", $subject_name, $id);
    $stmt->execute();

    header("Location: view_subjects.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Subject</title>
</head>
<body>

<h2>Edit Subject</h2>

<form method="POST">
    <label>Subject Name:</label><br>
    <input type="text" name="subject_name" value="<?php echo $row['subject_name']; ?>" required><br><br>

    <button type="submit" name="update">Update</button>
</form>

</body>
</html>