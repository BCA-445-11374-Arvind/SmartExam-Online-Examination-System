<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Access Denied");
}

// ADD SUBJECT
if(isset($_POST['add_subject'])){
    $subject_name = $_POST['subject_name'];
    mysqli_query($conn, "INSERT INTO subjects (subject_name) VALUES ('$subject_name')");
    header("Location: view_subjects.php");
    exit();
}

// DELETE SUBJECT
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM subjects WHERE id='$id'");
    header("Location: view_subjects.php");
    exit();
}

// FETCH SUBJECTS
$result = mysqli_query($conn, "SELECT * FROM subjects ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Subjects</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- ICONS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

body {
    background: linear-gradient(135deg, #1d2b64, #f8cdda);
    min-height: 100vh;
    color: white;
    font-family: 'Segoe UI', sans-serif;
}

/* GLASS */
.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
}

/* TABLE */
.table {
    color: white;
}

.table thead {
    background: rgba(0,0,0,0.4);
}

.table tbody tr:hover {
    background: rgba(255,255,255,0.1);
}

/* BUTTON */
.btn-custom {
    border-radius: 25px;
    padding: 5px 12px;
}

input {
    border-radius: 10px !important;
}

</style>
</head>

<body>

<div class="container py-4">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>📚 Manage Subjects</h2>

        <a href="../dashboard.php" class="btn btn-light">
            ⬅ Back to Dashboard
        </a>
    </div>

    <!-- ADD SUBJECT -->
    <div class="glass mb-4 shadow">

        <h5 class="mb-3">➕ Add Subject</h5>

        <form method="POST" class="d-flex gap-2">

            <input type="text" name="subject_name" class="form-control" placeholder="Enter subject name" required>

            <button type="submit" name="add_subject" class="btn btn-success btn-custom">
                Add
            </button>

        </form>

    </div>

    <!-- SUBJECT TABLE -->
    <div class="glass shadow">

        <table class="table table-bordered text-center align-middle">

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Subject Name</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

            <?php 
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
            ?>

                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['subject_name']; ?></td>

                    <td>
                        <a href="?delete=<?php echo $row['id']; ?>" 
                           class="btn btn-danger btn-custom"
                           onclick="return confirm('Delete this subject?');">
                           <i class="fa-solid fa-trash"></i> Delete
                        </a>
                    </td>
                </tr>

            <?php 
                }
            } else {
                echo "<tr><td colspan='3'>No Subjects Found ❌</td></tr>";
            }
            ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>