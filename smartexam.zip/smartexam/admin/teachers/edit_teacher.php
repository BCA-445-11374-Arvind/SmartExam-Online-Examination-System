<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Access Denied");
}

// VALIDATE ID
if(!isset($_GET['id'])){
    die("Invalid Request");
}

$id = $_GET['id'];

// FETCH DATA
$stmt = $conn->prepare("SELECT name, email FROM users WHERE id=? AND role='teacher'");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

// UPDATE
if(isset($_POST['update'])){
    $name = $_POST['name'];
    $email = $_POST['email'];

    $stmt = $conn->prepare("UPDATE users SET name=?, email=? WHERE id=? AND role='teacher'");
    $stmt->bind_param("ssi", $name, $email, $id);

    if($stmt->execute()){
        $success = "Teacher Updated Successfully ✅";
    } else {
        $error = "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Teacher</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-5">

    <div class="card shadow">
        <div class="card-header text-center bg-success text-white">
            <h4>Edit Teacher</h4>
        </div>

        <div class="card-body">

            <?php if(isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
            <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

            <form method="POST">

                <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input type="text" name="name" class="form-control" value="<?php echo $row['name']; ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo $row['email']; ?>" required>
                </div>

                <button type="submit" name="update" class="btn btn-success w-100">Update Teacher</button>

            </form>

        </div>
    </div>

    <div class="text-center mt-3">
        <a href="view_teachers.php" class="btn btn-secondary">Back</a>
    </div>

</div>

</body>
</html>