<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    die("Access Denied");
}

// FETCH TEACHERS
$query = "SELECT * FROM users WHERE role='teacher' ORDER BY id DESC";
$result = mysqli_query($conn, $query);

// DELETE TEACHER
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM users WHERE id='$id' AND role='teacher'");
    header("Location: view_teachers.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Manage Teachers</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- ICONS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

body {
    background: linear-gradient(135deg, #1d2b64, #f8cdda);
    min-height: 100vh;
    color: white;
    font-family: 'Segoe UI', sans-serif;
}

/* GLASS */
.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
}

/* TABLE */
.table {
    color: white;
}

.table thead {
    background: rgba(0,0,0,0.4);
}

.table tbody tr:hover {
    background: rgba(255,255,255,0.1);
}

/* BUTTON */
.btn-custom {
    border-radius: 25px;
    padding: 5px 12px;
}

</style>
</head>

<body>

<div class="container py-4">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>👨‍🏫 Manage Teachers</h2>

        <a href="../dashboard.php" class="btn btn-light">
            ⬅ Back to Dashboard
        </a>
    </div>

    <!-- TABLE -->
    <div class="glass shadow">

        <table class="table table-bordered text-center align-middle">

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

            <?php 
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
            ?>

                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['email']; ?></td>

                    <td>
                        <a href="?delete=<?php echo $row['id']; ?>" 
                           class="btn btn-danger btn-custom"
                           onclick="return confirm('Are you sure to delete this teacher?');">
                           <i class="fa-solid fa-trash"></i> Delete
                        </a>
                    </td>

                </tr>

            <?php 
                }
            } else {
                echo "<tr><td colspan='4'>No Teachers Found ❌</td></tr>";
            }
            ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>