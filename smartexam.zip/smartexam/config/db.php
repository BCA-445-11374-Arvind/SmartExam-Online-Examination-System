<?php
$host = "localhost";
$username = "root";
$password = "Arvind@494"; // yaha apna MySQL root password likho
$database = "smartexam";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}
?>
