<?php
session_start();
include("config/db.php");

if(isset($_POST['reset'])){

    $email = $_POST['email'];

    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

    if(mysqli_num_rows($check) > 0){
        $_SESSION['reset_email'] = $email;
        header("Location: reset_password.php");
        exit();
    } else {
        $error = "Email not found ❌";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Forgot Password</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body {
    background: linear-gradient(135deg, #667eea, #764ba2);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: 'Segoe UI', sans-serif;
}

/* GLASS CARD */
.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 30px;
    width: 100%;
    max-width: 400px;
    color: white;
}

.form-control {
    border-radius: 10px;
}

.btn-custom {
    border-radius: 25px;
}

</style>
</head>

<body>

<div class="glass shadow">

    <h3 class="text-center mb-3">🔑 Forgot Password</h3>
    <p class="text-center">Enter your email to reset password</p>

    <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

    <form method="POST">

        <div class="mb-3">
            <label>Email Address</label>
            <input type="email" name="email" class="form-control" required>
        </div>

        <button type="submit" name="reset" class="btn btn-light w-100 btn-custom">
            Continue
        </button>

    </form>

    <div class="text-center mt-3">
        <a href="login.php" class="text-white">⬅ Back to Login</a>
    </div>

</div>

</body>
</html>