<?php
$password = "123456";
$hashed = password_hash($password, PASSWORD_DEFAULT);

echo $hashed;
?>
