<?php
if(session_status() == PHP_SESSION_NONE){
    session_start();
}
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">

        <a class="navbar-brand fw-bold" href="/online_exam_system/">SmartExam</a>

        <div>

        <?php if(isset($_SESSION['role'])): ?>

            <?php if($_SESSION['role'] == 'admin'): ?>
                <a href="/online_exam_system/admin/dashboard.php" class="btn btn-outline-light btn-sm mx-1">Dashboard</a>
                <a href="/online_exam_system/admin/teachers/view_teachers.php" class="btn btn-outline-light btn-sm mx-1">Teachers</a>
                <a href="/online_exam_system/admin/subjects/view_subjects.php" class="btn btn-outline-light btn-sm mx-1">Subjects</a>
                <a href="/online_exam_system/admin/exams/add_exam.php" class="btn btn-outline-light btn-sm mx-1">Exams</a>

            <?php elseif($_SESSION['role'] == 'teacher'): ?>
                <a href="/online_exam_system/teacher/dashboard.php" class="btn btn-outline-light btn-sm mx-1">Dashboard</a>
                <a href="/online_exam_system/teacher/question_bank/view_questions.php" class="btn btn-outline-light btn-sm mx-1">Question Bank</a>

            <?php elseif($_SESSION['role'] == 'student'): ?>
                <a href="/online_exam_system/student/exam/index.php" class="btn btn-outline-light btn-sm mx-1">Exams</a>
                <a href="/online_exam_system/student/exam/result.php" class="btn btn-outline-light btn-sm mx-1">Results</a>

            <?php endif; ?>

            <a href="/online_exam_system/logout.php" class="btn btn-danger btn-sm mx-1">Logout</a>

        <?php else: ?>

            <a href="/online_exam_system/login.php" class="btn btn-primary btn-sm mx-1">Login</a>
            <a href="/online_exam_system/register.php" class="btn btn-success btn-sm mx-1">Register</a>

        <?php endif; ?>

        </div>

    </div>
</nav>