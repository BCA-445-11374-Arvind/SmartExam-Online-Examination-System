<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
<title>SmartExam - Online Examination System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

body {
    font-family: 'Segoe UI', sans-serif;
    scroll-behavior: smooth;
}

/* NAVBAR */
.navbar {
    background: rgba(0,0,0,0.7);
}

/* HERO */
.hero {
    height: 100vh;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    display: flex;
    justify-content: center;
    align-items: center;
    text-align: center;
}

.hero h1 {
    font-size: 55px;
    font-weight: bold;
}

.btn-custom {
    border-radius: 25px;
    padding: 10px 25px;
}

/* SECTION */
section {
    padding: 80px 0;
}

/* GLASS */
.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
}

/* FEATURES */
.feature-card {
    transition: 0.3s;
}

.feature-card:hover {
    transform: translateY(-10px);
}

/* CONTACT */
.contact {
    background: #111;
    color: white;
}

footer {
    background: black;
    color: white;
    text-align: center;
    padding: 10px;
}

</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top px-4">
    <a class="navbar-brand" href="#">SmartExam</a>

    <div class="ms-auto">
        <a href="#home" class="btn btn-outline-light btn-sm">Home</a>
        <a href="#about" class="btn btn-outline-light btn-sm">About</a>
        <a href="#features" class="btn btn-outline-light btn-sm">Features</a>
        <a href="#contact" class="btn btn-outline-light btn-sm">Contact</a>

        <a href="login.php" class="btn btn-light btn-sm">Login</a>
        <a href="register.php" class="btn btn-warning btn-sm">Register</a>
    </div>
</nav>

<!-- HERO -->
<section class="hero" id="home">
    <div>
        <h1>SmartExam 🎓</h1>
        <p>Modern Online Examination System</p>

        <a href="login.php" class="btn btn-light btn-custom">Get Started</a>
        <a href="register.php" class="btn btn-outline-light btn-custom">Register</a>
    </div>
</section>

<!-- ABOUT -->
<section id="about">
    <div class="container text-center">

        <h2 class="mb-4">About SmartExam</h2>

        <div class="glass">

            <p class="mb-3">
                SmartExam is a complete online examination system designed to simplify exam management and improve efficiency.
            </p>

            <ul class="text-start">
                <li>✔ Role-based system (Admin, Teacher, Student)</li>
                <li>✔ Secure login with password hashing</li>
                <li>✔ Teachers can create and manage exams easily</li>
                <li>✔ Students can attempt exams with timer system</li>
                <li>✔ Auto submission and instant result generation</li>
                <li>✔ One attempt restriction for fair evaluation</li>
                <li>✔ Admin can manage users and monitor results</li>
                <li>✔ Fully responsive and modern UI design</li>
            </ul>

        </div>

    </div>
</section>

<!-- FEATURES -->
<section id="features">
    <div class="container text-center">

        <h2 class="mb-5">Features</h2>

        <div class="row">

            <div class="col-md-4 mb-3">
                <div class="card p-4 feature-card shadow">
                    <i class="fa-solid fa-lock fa-2x mb-3"></i>
                    <h5>Secure System</h5>
                    <p>Authentication and role-based access control</p>
                </div>
            </div>

            <div class="col-md-4 mb-3">
                <div class="card p-4 feature-card shadow">
                    <i class="fa-solid fa-clock fa-2x mb-3"></i>
                    <h5>Live Timer</h5>
                    <p>Real-time countdown with auto submission</p>
                </div>
            </div>

            <div class="col-md-4 mb-3">
                <div class="card p-4 feature-card shadow">
                    <i class="fa-solid fa-chart-line fa-2x mb-3"></i>
                    <h5>Instant Results</h5>
                    <p>Quick evaluation with percentage and status</p>
                </div>
            </div>

        </div>

    </div>
</section>

<!-- CONTACT -->
<section class="contact text-center" id="contact">
    <div class="container">

        <h2>Contact Us</h2>

        <div class="row justify-content-center mt-4">

            <div class="col-md-3">
                <p>📞 +91 9142900494</p>
            </div>

            <div class="col-md-3">
                <p>📧 support@smartexam.com</p>
            </div>

            <div class="col-md-3">
                <p>📍 Patna, Bihar, India</p>
            </div>

        </div>

    </div>
</section>

<footer>
    © 2026 SmartExam | All Rights Reserved
</footer>

</body>
</html>