<?php
session_start();
include("config/db.php");

if(isset($_POST['login'])){

    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $query);

    if(mysqli_num_rows($result) == 1){

        $user = mysqli_fetch_assoc($result);

        // PASSWORD VERIFY (HASH)
        if(password_verify($password, $user['password'])){

            if($user['status'] == 'blocked'){
                $error = "🚫 Your account is blocked!";
            } else {

                $_SESSION['user_id'] = $user['id'];
                $_SESSION['role'] = $user['role'];

                if($user['role'] == 'admin'){
                    header("Location: admin/dashboard.php");
                }
                elseif($user['role'] == 'teacher'){
                    header("Location: teacher/dashboard.php");
                }
                else{
                    header("Location: student/dashboard.php");
                }
                exit();
            }

        } else {
            $error = "❌ Wrong Password!";
        }

    } else {
        $error = "❌ Email not found!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>SmartExam Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(135deg, #36d1dc, #5b86e5);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: 'Segoe UI', sans-serif;
}

.login-card {
    width: 100%;
    max-width: 400px;
    border-radius: 15px;
    overflow: hidden;
}

.card-header {
    font-size: 22px;
    font-weight: bold;
}

.form-control {
    border-radius: 10px;
}

.btn-login {
    border-radius: 10px;
    font-weight: bold;
}

.links {
    display: flex;
    justify-content: space-between;
    font-size: 14px;
}

.home-link {
    text-align: center;
    margin-top: 15px;
}
</style>
</head>

<body>

<div class="card shadow-lg login-card">

    <div class="card-header text-center bg-dark text-white">
        🔐 SmartExam Login
    </div>

    <div class="card-body p-4">

        <h3 class="text-center mb-3">Welcome 👋</h3>

        <?php if(isset($error)) echo "<div class='alert alert-danger text-center'>$error</div>"; ?>

        <form method="POST">

            <div class="mb-3">
                <label>Email Address</label>
                <input type="email" name="email" class="form-control" placeholder="Enter email" required>
            </div>

            <div class="mb-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter password" required>
            </div>

            <!-- LINKS -->
            <div class="links mb-3">
                <a href="forgot_password.php">Forgot Password?</a>
                <a href="register.php">Register</a>
            </div>

            <button type="submit" name="login" class="btn btn-primary w-100 btn-login">
                Login
            </button>

        </form>

        <!-- BACK TO HOME -->
        <div class="home-link">
            <a href="index.php">⬅ Back to Home</a>
        </div>

    </div>

</div>

</body>
</html>