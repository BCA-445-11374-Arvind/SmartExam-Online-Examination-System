<?php
session_start();
include("config/db.php");

if(isset($_POST['register'])){

    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    // NAME VALIDATION (only letters)
    if(!preg_match("/^[a-zA-Z ]+$/", $name)){
        $error = "Name must contain only letters ❌";
    }

    // EMAIL VALIDATION
    elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $error = "Invalid email format ❌";
    }

    // PASSWORD MATCH
    elseif($password != $confirm){
        $error = "Passwords do not match ❌";
    }

    // STRONG PASSWORD
    elseif(!preg_match("/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/", $password)){
        $error = "Password must be at least 6 characters and include letters & numbers ❌";
    }

    else{

        // CHECK EMAIL EXISTS
        $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

        if(mysqli_num_rows($check) > 0){
            $error = "Email already exists ❌";
        } else {

            // HASH PASSWORD
            $hashed = password_hash($password, PASSWORD_DEFAULT);

            mysqli_query($conn, "
                INSERT INTO users (name, email, password, role, status) 
                VALUES ('$name','$email','$hashed','student','active')
            ");

            $success = "Registration successful 🎉";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Register - SmartExam</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body {
    background: linear-gradient(135deg, #667eea, #764ba2);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: 'Segoe UI', sans-serif;
}

.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(12px);
    border-radius: 15px;
    padding: 30px;
    width: 100%;
    max-width: 400px;
    color: white;
}

.form-control {
    border-radius: 10px;
}

.btn-custom {
    border-radius: 25px;
}

/* Input focus effect */
.form-control:focus {
    box-shadow: 0 0 10px rgba(255,255,255,0.5);
}

</style>
</head>

<body>

<div class="glass shadow">

    <h3 class="text-center mb-4">📝 Create Account</h3>

    <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
    <?php if(isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>

    <form method="POST">

        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" required 
            pattern="[A-Za-z ]+" title="Only letters allowed">
        </div>

        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required minlength="6">
        </div>

        <div class="mb-3">
            <label>Confirm Password</label>
            <input type="password" name="confirm_password" class="form-control" required>
        </div>

        <button type="submit" name="register" class="btn btn-light w-100 btn-custom">
            Register
        </button>

    </form>

    <div class="text-center mt-3">
        <a href="login.php" class="text-white">Already have account? Login</a><br>
        <a href="index.php" class="text-white">⬅ Back to Home</a>
    </div>

</div>

</body>
</html>