<?php
session_start();
include("config/db.php");

// CHECK SESSION
if(!isset($_SESSION['reset_email'])){
    header("Location: forgot_password.php");
    exit();
}

if(isset($_POST['update'])){

    $password = $_POST['password'];
    $confirm = $_POST['confirm'];

    if($password != $confirm){
        $error = "Passwords do not match ❌";
    } else {

        // HASH PASSWORD
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        mysqli_query($conn, "
            UPDATE users SET password='$hashed' 
            WHERE email='{$_SESSION['reset_email']}'
        ");

        session_destroy();

        echo "<script>alert('Password Updated Successfully 🎉'); window.location='login.php';</script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Reset Password</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body {
    background: linear-gradient(135deg, #667eea, #764ba2);
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: 'Segoe UI', sans-serif;
}

.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 30px;
    width: 100%;
    max-width: 400px;
    color: white;
}

.form-control {
    border-radius: 10px;
}

.btn-custom {
    border-radius: 25px;
}

</style>
</head>

<body>

<div class="glass shadow">

    <h3 class="text-center mb-3">🔐 Reset Password</h3>

    <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

    <form method="POST">

        <div class="mb-3">
            <label>New Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Confirm Password</label>
            <input type="password" name="confirm" class="form-control" required>
        </div>

        <button type="submit" name="update" class="btn btn-light w-100 btn-custom">
            Update Password
        </button>

    </form>

</div>

</body>
</html>