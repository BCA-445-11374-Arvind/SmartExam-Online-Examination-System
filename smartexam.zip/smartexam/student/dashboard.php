<?php
session_start();
include("../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'student'){
    die("Access Denied");
}

$student_id = $_SESSION['user_id'];

// TOTAL EXAMS
$total_exam = mysqli_query($conn, "SELECT COUNT(*) as total FROM exams WHERE status='active'");
$total_exam = mysqli_fetch_assoc($total_exam)['total'];

// ATTEMPTED
$attempted = mysqli_query($conn, "SELECT COUNT(*) as total FROM results WHERE student_id='$student_id'");
$attempted = mysqli_fetch_assoc($attempted)['total'];

// PENDING
$pending = $total_exam - $attempted;
?>

<!DOCTYPE html>
<html>
<head>
<title>Student Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- ICONS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

body {
    background: linear-gradient(135deg, #667eea, #764ba2);
    min-height: 100vh;
    color: white;
    font-family: 'Segoe UI', sans-serif;
}

/* GLASS CARD */
.glass {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    color: white;
    transition: 0.3s;
}

.glass:hover {
    transform: translateY(-8px);
}

/* STATS */
.stat-card {
    padding: 25px;
    text-align: center;
}

/* BUTTONS */
.btn-custom {
    border-radius: 25px;
    padding: 10px 20px;
}

</style>
</head>

<body>

<div class="container py-4">

    <h2 class="mb-4">
        🎓 Student Dashboard
    </h2>

    <!-- STATS -->
    <div class="row">

        <div class="col-md-4 mb-3">
            <div class="glass stat-card shadow">
                <h3><i class="fa-solid fa-book"></i></h3>
                <h2><?php echo $total_exam; ?></h2>
                <p>Total Exams</p>
            </div>
        </div>

        <div class="col-md-4 mb-3">
            <div class="glass stat-card shadow">
                <h3><i class="fa-solid fa-check"></i></h3>
                <h2><?php echo $attempted; ?></h2>
                <p>Attempted</p>
            </div>
        </div>

        <div class="col-md-4 mb-3">
            <div class="glass stat-card shadow">
                <h3><i class="fa-solid fa-clock"></i></h3>
                <h2><?php echo $pending; ?></h2>
                <p>Pending</p>
            </div>
        </div>

    </div>

    <!-- ACTIONS -->
    <div class="glass p-4 mt-4 shadow text-center">

        <h4 class="mb-3">⚡ Quick Actions</h4>

        <a href="exam/index.php" class="btn btn-primary btn-custom m-2">
            <i class="fa-solid fa-list"></i> View Exams
        </a>

        <a href="exam/result.php" class="btn btn-success btn-custom m-2">
            <i class="fa-solid fa-chart-line"></i> Results
        </a>

        <a href="../logout.php" class="btn btn-danger btn-custom m-2">
            <i class="fa-solid fa-sign-out-alt"></i> Logout
        </a>

    </div>

</div>

</body>
</html>