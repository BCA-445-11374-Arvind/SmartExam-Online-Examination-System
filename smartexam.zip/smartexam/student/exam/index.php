<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'student'){
    die("Access Denied");
}

$student_id = $_SESSION['user_id'];

// FETCH EXAMS
$query = "
SELECT e.*, s.subject_name 
FROM exams e
JOIN subjects s ON e.subject_id = s.id
WHERE e.status='active'
";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
<title>Available Exams</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- ICONS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

body {
    background: linear-gradient(135deg, #667eea, #764ba2);
    min-height: 100vh;
    color: white;
    font-family: 'Segoe UI', sans-serif;
}

/* GLASS CARD */
.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
}

/* TABLE */
.table {
    color: white;
}

.table thead {
    background: rgba(0,0,0,0.4);
}

.table tbody tr:hover {
    background: rgba(255,255,255,0.1);
}

/* BUTTONS */
.btn-custom {
    border-radius: 25px;
    padding: 6px 15px;
}

.badge {
    font-size: 14px;
    padding: 6px 12px;
}

</style>
</head>

<body>

<div class="container py-4">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>📘 Available Exams</h2>

        <!-- BACK BUTTON -->
        <a href="../dashboard.php" class="btn btn-light btn-custom">
            ⬅ Back to Dashboard
        </a>
    </div>

    <!-- TABLE -->
    <div class="glass shadow">

        <table class="table table-bordered text-center align-middle">

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Subject</th>
                    <th>Date</th>
                    <th>Duration</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>

            <?php 
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){

                    // 🔒 CHECK ATTEMPT
                    $check = mysqli_query($conn, "
                        SELECT * FROM results 
                        WHERE student_id='$student_id' 
                        AND exam_id='{$row['id']}'
                    ");
            ?>

                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['title']; ?></td>
                    <td><?php echo $row['subject_name']; ?></td>

                    <!-- DATE -->
                    <td>
                        <?php echo date("d M Y, h:i A", strtotime($row['date'])); ?>
                    </td>

                    <td><?php echo $row['duration']; ?> min</td>

                    <td>
                        <?php 
                        if(mysqli_num_rows($check) > 0){
                            echo "<span class='badge bg-secondary'>✔ Attempted</span>";
                        } else {
                        ?>
                            <a href="start_exam.php?exam_id=<?php echo $row['id']; ?>" 
                               class="btn btn-success btn-custom">
                               <i class="fa-solid fa-play"></i> Start
                            </a>
                        <?php } ?>
                    </td>
                </tr>

            <?php 
                }
            } else {
                echo "<tr><td colspan='6'>No Exams Available ❌</td></tr>";
            }
            ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>