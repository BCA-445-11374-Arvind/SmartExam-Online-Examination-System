<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'student'){
    die("Access Denied");
}

$student_id = $_SESSION['user_id'];

// FETCH RESULTS
$query = "
SELECT r.*, e.title, e.total_marks 
FROM results r
JOIN exams e ON r.exam_id = e.id
WHERE r.student_id = '$student_id'
ORDER BY r.id DESC
";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
<title>My Results</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- ICONS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

body {
    background: linear-gradient(135deg, #667eea, #764ba2);
    min-height: 100vh;
    color: white;
    font-family: 'Segoe UI', sans-serif;
}

/* GLASS CARD */
.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
}

/* TABLE */
.table {
    color: white;
}

.table thead {
    background: rgba(0,0,0,0.4);
}

.table tbody tr:hover {
    background: rgba(255,255,255,0.1);
}

/* BADGE */
.badge {
    padding: 6px 12px;
    font-size: 14px;
}

.highlight {
    font-weight: bold;
    font-size: 16px;
}

</style>
</head>

<body>

<div class="container py-4">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>📊 My Results</h2>

        <a href="../dashboard.php" class="btn btn-light">
            ⬅ Back to Dashboard
        </a>
    </div>

    <!-- RESULT TABLE -->
    <div class="glass shadow">

        <table class="table table-bordered text-center align-middle">

            <thead>
                <tr>
                    <th>Exam</th>
                    <th>Score</th>
                    <th>Total</th>
                    <th>Percentage</th>
                    <th>Status</th>
                </tr>
            </thead>

            <tbody>

            <?php 
            if(mysqli_num_rows($result) > 0){

                while($row = mysqli_fetch_assoc($result)){

                    // SAFE CALCULATION
                    $total = $row['total_marks'] ?? 0;

                    if($total > 0){
                        $percentage = ($row['score'] / $total) * 100;
                    } else {
                        $percentage = 0;
                    }

                    $percentage = round($percentage, 2);

                    // PASS / FAIL
                    if($percentage >= 40){
                        $status = "Pass";
                        $badge = "success";
                    } else {
                        $status = "Fail";
                        $badge = "danger";
                    }
            ?>

                <tr>
                    <td><?php echo $row['title']; ?></td>
                    <td class="highlight"><?php echo $row['score']; ?></td>
                    <td><?php echo $total; ?></td>
                    <td class="highlight"><?php echo $percentage; ?>%</td>
                    <td>
                        <span class="badge bg-<?php echo $badge; ?>">
                            <?php echo $status; ?>
                        </span>
                    </td>
                </tr>

            <?php 
                }
            } else {
                echo "<tr><td colspan='5'>No Results Found ❌</td></tr>";
            }
            ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>