<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'student'){
    die("Access Denied");
}

$student_id = $_SESSION['user_id'];
$exam_id = $_GET['exam_id'];

// 🚨 ONE ATTEMPT CHECK
$check = mysqli_query($conn, "
    SELECT * FROM results 
    WHERE student_id='$student_id' AND exam_id='$exam_id'
");

if(mysqli_num_rows($check) > 0){
    echo "<script>alert('You have already attempted this exam ❌'); window.location='index.php';</script>";
    exit();
}

// FETCH EXAM
$exam = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM exams WHERE id='$exam_id'"));

// FETCH QUESTIONS
$query = "
SELECT q.* 
FROM exam_questions eq
JOIN question_bank q ON eq.question_id = q.id
WHERE eq.exam_id='$exam_id'
";
$result = mysqli_query($conn, $query);

// SUBMIT
if(isset($_POST['submit_exam'])){

    $answers = $_POST['answers'] ?? [];
    $score = 0;

    foreach($answers as $qid => $ans){

        $res = mysqli_fetch_assoc(mysqli_query($conn, "SELECT correct_option FROM question_bank WHERE id='$qid'"));

        if($res && $res['correct_option'] == $ans){
            $score++;
        }

        mysqli_query($conn, "INSERT INTO student_answers (student_id, exam_id, question_id, selected_option)
                             VALUES ('$student_id','$exam_id','$qid','$ans')");
    }

    mysqli_query($conn, "INSERT INTO results (student_id, exam_id, score)
                         VALUES ('$student_id','$exam_id','$score')");

    echo "<script>alert('Exam Submitted! Your Score: $score'); window.location='result.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Start Exam</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
}

.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 20px;
}

.timer {
    position: fixed;
    top: 20px;
    right: 20px;
    background: red;
    padding: 10px;
    border-radius: 10px;
}

</style>

<script>
let time = <?php echo $exam['duration'] * 60; ?>;

function startTimer(){
    let t = document.getElementById("timer");

    setInterval(function(){
        let m = Math.floor(time/60);
        let s = time%60;

        t.innerHTML = m + ":" + (s<10?"0":"") + s;

        time--;

        if(time < 0){
            alert("Time up!");
            document.getElementById("examForm").submit();
        }

    },1000);
}

window.onload = startTimer;
</script>

</head>

<body>

<div class="timer">⏱️ <span id="timer"></span></div>

<div class="container py-4">

<h2>📝 Exam</h2>

<form method="POST" id="examForm">

<?php 
$qno=1;
while($row=mysqli_fetch_assoc($result)){
?>

<div class="glass mb-3">
<h5>Q<?php echo $qno++; ?>. <?php echo $row['question']; ?></h5>

<label><input type="radio" name="answers[<?php echo $row['id']; ?>]" value="1" required> <?php echo $row['option1']; ?></label><br>
<label><input type="radio" name="answers[<?php echo $row['id']; ?>]" value="2"> <?php echo $row['option2']; ?></label><br>
<label><input type="radio" name="answers[<?php echo $row['id']; ?>]" value="3"> <?php echo $row['option3']; ?></label><br>
<label><input type="radio" name="answers[<?php echo $row['id']; ?>]" value="4"> <?php echo $row['option4']; ?></label>

</div>

<?php } ?>

<button class="btn btn-success w-100" name="submit_exam">Submit</button>

</form>

</div>

</body>
</html>