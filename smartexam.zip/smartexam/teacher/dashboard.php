<?php
session_start();
include("../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'teacher'){
    die("Access Denied");
}

$teacher_id = $_SESSION['user_id'];

// STATS

// Total Exams
$exams = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) as total FROM exams WHERE teacher_id='$teacher_id'
"))['total'];

// Total Questions
$questions = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) as total FROM question_bank
"))['total'];

// Total Results
$results = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT COUNT(*) as total 
    FROM results r
    JOIN exams e ON r.exam_id = e.id
    WHERE e.teacher_id='$teacher_id'
"))['total'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Teacher Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- ICONS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>

body {
    background: linear-gradient(135deg, #0f2027, #2c5364);
    min-height: 100vh;
    color: white;
    font-family: 'Segoe UI', sans-serif;
}

.glass {
    background: rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
    border-radius: 15px;
    padding: 25px;
    text-align: center;
    transition: 0.3s;
}

.glass:hover {
    transform: translateY(-8px);
}

.btn-custom {
    border-radius: 25px;
    padding: 10px 20px;
}

</style>
</head>

<body>

<div class="container py-4">

    <h2 class="mb-4">👨‍🏫 Teacher Dashboard</h2>

    <!-- STATS -->
    <div class="row">

        <div class="col-md-4 mb-3">
            <div class="glass shadow">
                <h3><i class="fa-solid fa-book"></i></h3>
                <h2><?php echo $exams; ?></h2>
                <p>Total Exams</p>
            </div>
        </div>

        <div class="col-md-4 mb-3">
            <div class="glass shadow">
                <h3><i class="fa-solid fa-question"></i></h3>
                <h2><?php echo $questions; ?></h2>
                <p>Total Questions</p>
            </div>
        </div>

        <div class="col-md-4 mb-3">
            <div class="glass shadow">
                <h3><i class="fa-solid fa-chart-line"></i></h3>
                <h2><?php echo $results; ?></h2>
                <p>Student Attempts</p>
            </div>
        </div>

    </div>

    <!-- ACTIONS -->
    <div class="glass mt-4 shadow text-center">

        <h4 class="mb-3">⚡ Quick Actions</h4>

        <!-- ✅ FIXED LINKS -->
        <a href="exams/add_exam.php" class="btn btn-primary btn-custom m-2">
            <i class="fa-solid fa-plus"></i> Create Exam
        </a>

        <a href="exams/view_exams.php" class="btn btn-success btn-custom m-2">
            <i class="fa-solid fa-list"></i> Manage Exams
        </a>

        <a href="question_bank/view_questions.php" class="btn btn-warning btn-custom m-2">
            <i class="fa-solid fa-database"></i> Question Bank
        </a>

        <a href="../logout.php" class="btn btn-danger btn-custom m-2">
            <i class="fa-solid fa-sign-out-alt"></i> Logout
        </a>

    </div>

</div>

</body>
</html>