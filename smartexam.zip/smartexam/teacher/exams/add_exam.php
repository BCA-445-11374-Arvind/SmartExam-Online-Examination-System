<?php
session_start();
include("../../config/db.php");

if(!isset($_SESSION['role']) || $_SESSION['role'] != 'teacher'){
    die("Access Denied");
}

$teacher_id = $_SESSION['user_id'];
$subjects = $conn->query("SELECT * FROM subjects");

if(isset($_POST['add_exam'])){
    $title = $_POST['title'];
    $subject_id = $_POST['subject_id'];
    $date = $_POST['date'];
    $duration = $_POST['duration'];
    $total_marks = $_POST['total_marks'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("INSERT INTO exams (title, subject_id, date, duration, total_marks, teacher_id, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sisiiis", $title, $subject_id, $date, $duration, $total_marks, $teacher_id, $status);

    if($stmt->execute()){
        $success = "Exam Created Successfully ✅";
    } else {
        $error = "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Create Exam</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-5">
<div class="card shadow">
<div class="card-header bg-primary text-white text-center">
<h4>Create Exam</h4>
</div>

<div class="card-body">

<?php if(isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
<?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

<form method="POST">

<div class="mb-3">
<label>Title</label>
<input type="text" name="title" class="form-control" required>
</div>

<div class="mb-3">
<label>Subject</label>
<select name="subject_id" class="form-control" required>
<option value="">Select</option>
<?php while($row=$subjects->fetch_assoc()){
echo "<option value='".$row['id']."'>".$row['subject_name']."</option>";
} ?>
</select>
</div>

<div class="mb-3">
<label>Date</label>
<input type="datetime-local" name="date" class="form-control" required>
</div>

<div class="mb-3">
<label>Duration</label>
<input type="number" name="duration" class="form-control" required>
</div>

<div class="mb-3">
<label>Total Marks</label>
<input type="number" name="total_marks" class="form-control" required>
</div>

<div class="mb-3">
<label>Status</label>
<select name="status" class="form-control">
<option value="inactive">Inactive</option>
<option value="active">Active</option>
</select>
</div>

<button type="submit" name="add_exam" class="btn btn-primary w-100">Create</button>

</form>

</div>
</div>
</div>

</body>
</html>