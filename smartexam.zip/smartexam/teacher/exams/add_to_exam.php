<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'teacher'){
    die("Access Denied");
}

$question_id = $_GET['question_id'];

// FETCH EXAMS
$result = mysqli_query($conn, "
    SELECT * FROM exams 
    WHERE teacher_id='{$_SESSION['user_id']}'
");

// ADD TO EXAM
if(isset($_POST['add'])){
    $exam_id = $_POST['exam_id'];

    mysqli_query($conn, "
        INSERT INTO exam_questions (exam_id, question_id)
        VALUES ('$exam_id', '$question_id')
    ");

    echo "<script>alert('Question added to exam 🎉'); window.location='../question_bank/view_questions.php';</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Add to Exam</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-5">

    <div class="card shadow">
        <div class="card-body">

            <h4>Select Exam</h4>

            <form method="POST">

                <select name="exam_id" class="form-control mb-3" required>
                    <option value="">-- Select Exam --</option>

                    <?php
                    while($row = mysqli_fetch_assoc($result)){
                        echo "<option value='".$row['id']."'>".$row['title']."</option>";
                    }
                    ?>

                </select>

                <button name="add" class="btn btn-success w-100">
                    Add Question
                </button>

            </form>

        </div>
    </div>

</div>

</body>
</html>