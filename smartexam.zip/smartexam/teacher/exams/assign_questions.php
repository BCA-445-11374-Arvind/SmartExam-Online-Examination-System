<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'teacher'){
    die("Access Denied");
}

$teacher_id = $_SESSION['user_id'];

// FETCH TEACHER EXAMS
$exams = $conn->prepare("SELECT * FROM exams WHERE teacher_id=?");
$exams->bind_param("i", $teacher_id);
$exams->execute();
$exam_result = $exams->get_result();

// FETCH TEACHER QUESTIONS
$questions = $conn->prepare("SELECT * FROM question_bank WHERE teacher_id=?");
$questions->bind_param("i", $teacher_id);
$questions->execute();
$question_result = $questions->get_result();

// ASSIGN
if(isset($_POST['assign'])){
    $exam_id = $_POST['exam_id'];
    $question_ids = $_POST['questions'];

    foreach($question_ids as $qid){

        // PREVENT DUPLICATE
        $check = $conn->prepare("SELECT * FROM exam_questions WHERE exam_id=? AND question_id=?");
        $check->bind_param("ii", $exam_id, $qid);
        $check->execute();
        $res = $check->get_result();

        if($res->num_rows == 0){
            $stmt = $conn->prepare("INSERT INTO exam_questions (exam_id, question_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $exam_id, $qid);
            $stmt->execute();
        }
    }

    $success = "Questions Assigned Successfully ✅";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assign Questions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-4">

    <div class="card shadow">
        <div class="card-header text-center bg-info text-white">
            <h4>Assign Questions</h4>
        </div>

        <div class="card-body">

            <?php if(isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>

            <form method="POST">

                <div class="mb-3">
                    <label>Select Exam</label>
                    <select name="exam_id" class="form-control" required>
                        <option value="">Select Exam</option>
                        <?php
                        while($e = $exam_result->fetch_assoc()){
                            echo "<option value='".$e['id']."'>".$e['title']."</option>";
                        }
                        ?>
                    </select>
                </div>

                <label>Select Questions</label>

                <div class="border p-3" style="max-height:300px; overflow-y:auto;">
                    <?php
                    while($q = $question_result->fetch_assoc()){
                        echo "
                        <div class='form-check'>
                            <input class='form-check-input' type='checkbox' name='questions[]' value='".$q['id']."'>
                            <label class='form-check-label'>
                                ".$q['question']."
                            </label>
                        </div>";
                    }
                    ?>
                </div>

                <br>

                <button type="submit" name="assign" class="btn btn-info w-100">Assign Questions</button>

            </form>

        </div>
    </div>

    <div class="text-center mt-3">
        <a href="../dashboard.php" class="btn btn-secondary">Back</a>
    </div>

</div>

</body>
</html>