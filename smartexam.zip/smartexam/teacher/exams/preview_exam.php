<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'teacher'){
    die("Access Denied");
}

$exam_id = $_GET['exam_id'];

// FETCH QUESTIONS
$stmt = $conn->prepare("
    SELECT q.* 
    FROM exam_questions eq
    JOIN question_bank q ON eq.question_id = q.id
    WHERE eq.exam_id=?
");
$stmt->bind_param("i", $exam_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Preview Exam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-4">

    <h3 class="text-center mb-4">Exam Preview</h3>

    <div class="card shadow">
        <div class="card-body">

            <?php
            $count = 0;
            while($row = $result->fetch_assoc()){
                $count++;
                echo "<div class='mb-3'>
                    <b>Q$count. ".$row['question']."</b><br>
                    1. ".$row['option1']."<br>
                    2. ".$row['option2']."<br>
                    3. ".$row['option3']."<br>
                    4. ".$row['option4']."<br>
                </div>";
            }

            if($count == 0){
                echo "<div class='alert alert-danger text-center'>No Questions Assigned ❌</div>";
            } else {
                echo "<div class='alert alert-success text-center'>Total Questions: $count</div>";
            }
            ?>

        </div>
    </div>

    <div class="text-center mt-3">
        <a href="view_exams.php" class="btn btn-secondary">Back</a>
    </div>

</div>

</body>
</html>