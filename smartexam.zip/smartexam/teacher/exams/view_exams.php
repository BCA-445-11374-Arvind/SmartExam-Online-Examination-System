<?php
session_start();
include("../../config/db.php");

if(!isset($_SESSION['role']) || $_SESSION['role'] != 'teacher'){
    die("Access Denied");
}

$teacher_id = $_SESSION['user_id'];

// 🔥 STATUS TOGGLE
if(isset($_GET['toggle'])){
    $id = $_GET['toggle'];

    $res = mysqli_query($conn, "SELECT status FROM exams WHERE id='$id'");
    $row = mysqli_fetch_assoc($res);

    $new_status = ($row['status'] == 'active') ? 'inactive' : 'active';

    mysqli_query($conn, "UPDATE exams SET status='$new_status' WHERE id='$id'");

    header("Location: view_exams.php");
    exit();
}

// FETCH EXAMS
$stmt = $conn->prepare("
SELECT e.*, s.subject_name 
FROM exams e
JOIN subjects s ON e.subject_id = s.id
WHERE e.teacher_id=?
");
$stmt->bind_param("i",$teacher_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
<title>My Exams</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
}
.card {
    border-radius: 15px;
}
.table {
    color: white;
}
.table thead {
    background: rgba(0,0,0,0.5);
}
.table tbody tr:hover {
    background: rgba(255,255,255,0.1);
}
</style>

</head>

<body>

<div class="container mt-4">

<div class="d-flex justify-content-between mb-3">
    <h3>📘 My Exams</h3>
    <a href="../dashboard.php" class="btn btn-light">⬅ Back</a>
</div>

<div class="card shadow">
<div class="card-body">

<table class="table table-bordered text-center align-middle">

<thead>
<tr>
<th>Title</th>
<th>Subject</th>
<th>Date</th>
<th>Duration</th>
<th>Marks</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>

<tbody>

<?php 
if($result->num_rows > 0){
while($row=$result->fetch_assoc()){ 
?>

<tr>
<td><?php echo $row['title']; ?></td>
<td><?php echo $row['subject_name']; ?></td>
<td><?php echo date("d M Y", strtotime($row['date'])); ?></td>
<td><?php echo $row['duration']; ?> min</td>
<td><?php echo $row['total_marks']; ?></td>

<td>
<?php if($row['status']=='active'){ ?>
    <span class="badge bg-success">Active</span>
<?php } else { ?>
    <span class="badge bg-danger">Inactive</span>
<?php } ?>
</td>

<td>

<a href="preview_exam.php?exam_id=<?php echo $row['id']; ?>" 
class="btn btn-info btn-sm">Preview</a>

<?php if($row['status']=='active'){ ?>
<a href="?toggle=<?php echo $row['id']; ?>" 
class="btn btn-danger btn-sm">Deactivate</a>
<?php } else { ?>
<a href="?toggle=<?php echo $row['id']; ?>" 
class="btn btn-success btn-sm">Activate</a>
<?php } ?>

</td>

</tr>

<?php 
}
}else{
    echo "<tr><td colspan='7'>No Exams Found ❌</td></tr>";
}
?>

</tbody>

</table>

</div>
</div>

</div>

</body>
</html>