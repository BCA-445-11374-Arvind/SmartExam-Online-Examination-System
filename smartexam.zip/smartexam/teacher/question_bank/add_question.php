<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'teacher'){
    die("Access Denied");
}

$teacher_id = $_SESSION['user_id'];

// FETCH SUBJECTS
$subjects = $conn->query("SELECT * FROM subjects");

// ADD QUESTION
if(isset($_POST['add_question'])){
    $subject_id = $_POST['subject_id'];
    $question = $_POST['question'];
    $option1 = $_POST['option1'];
    $option2 = $_POST['option2'];
    $option3 = $_POST['option3'];
    $option4 = $_POST['option4'];
    $correct_option = $_POST['correct_option'];

    $stmt = $conn->prepare("INSERT INTO question_bank 
        (subject_id, teacher_id, question, option1, option2, option3, option4, correct_option) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param("iisssssi", $subject_id, $teacher_id, $question, $option1, $option2, $option3, $option4, $correct_option);

    if($stmt->execute()){
        $success = "Question Added Successfully ✅";
    } else {
        $error = "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Question</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-4">

    <div class="card shadow">
        <div class="card-header text-center bg-primary text-white">
            <h4>Add Question</h4>
        </div>

        <div class="card-body">

            <?php if(isset($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
            <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

            <form method="POST">

                <div class="mb-3">
                    <label class="form-label">Subject</label>
                    <select name="subject_id" class="form-control" required>
                        <option value="">Select Subject</option>
                        <?php
                        while($row = $subjects->fetch_assoc()){
                            echo "<option value='".$row['id']."'>".$row['subject_name']."</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Question</label>
                    <textarea name="question" class="form-control" required></textarea>
                </div>

                <div class="mb-3">
                    <label>Option 1</label>
                    <input type="text" name="option1" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Option 2</label>
                    <input type="text" name="option2" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Option 3</label>
                    <input type="text" name="option3" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Option 4</label>
                    <input type="text" name="option4" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Correct Option</label>
                    <select name="correct_option" class="form-control" required>
                        <option value="">Select</option>
                        <option value="1">Option 1</option>
                        <option value="2">Option 2</option>
                        <option value="3">Option 3</option>
                        <option value="4">Option 4</option>
                    </select>
                </div>

                <button type="submit" name="add_question" class="btn btn-primary w-100">Add Question</button>

            </form>

        </div>
    </div>

    <div class="text-center mt-3">
        <a href="../dashboard.php" class="btn btn-secondary">Back</a>
    </div>

</div>

</body>
</html>