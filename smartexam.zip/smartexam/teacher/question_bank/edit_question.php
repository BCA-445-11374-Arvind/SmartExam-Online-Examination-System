<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'teacher'){
    die("Access Denied");
}

$teacher_id = $_SESSION['user_id'];

// VALIDATE ID
if(!isset($_GET['id'])){
    die("Invalid Request");
}

$id = $_GET['id'];

// FETCH QUESTION
$stmt = $conn->prepare("SELECT * FROM question_bank WHERE id=? AND teacher_id=?");
$stmt->bind_param("ii", $id, $teacher_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

// FETCH SUBJECTS
$subjects = $conn->query("SELECT * FROM subjects");

// UPDATE
if(isset($_POST['update'])){
    $subject_id = $_POST['subject_id'];
    $question = $_POST['question'];
    $option1 = $_POST['option1'];
    $option2 = $_POST['option2'];
    $option3 = $_POST['option3'];
    $option4 = $_POST['option4'];
    $correct_option = $_POST['correct_option'];

    $stmt = $conn->prepare("UPDATE question_bank 
        SET subject_id=?, question=?, option1=?, option2=?, option3=?, option4=?, correct_option=? 
        WHERE id=? AND teacher_id=?");

    $stmt->bind_param("isssssiii", $subject_id, $question, $option1, $option2, $option3, $option4, $correct_option, $id, $teacher_id);
    $stmt->execute();

    header("Location: view_questions.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Question</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-4">

    <div class="card shadow">
        <div class="card-header text-center bg-success text-white">
            <h4>Edit Question</h4>
        </div>

        <div class="card-body">

            <form method="POST">

                <div class="mb-3">
                    <label>Subject</label>
                    <select name="subject_id" class="form-control" required>
                        <?php
                        while($s = $subjects->fetch_assoc()){
                            $selected = ($s['id'] == $row['subject_id']) ? "selected" : "";
                            echo "<option value='".$s['id']."' $selected>".$s['subject_name']."</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Question</label>
                    <textarea name="question" class="form-control" required><?php echo $row['question']; ?></textarea>
                </div>

                <div class="mb-3">
                    <label>Option 1</label>
                    <input type="text" name="option1" class="form-control" value="<?php echo $row['option1']; ?>" required>
                </div>

                <div class="mb-3">
                    <label>Option 2</label>
                    <input type="text" name="option2" class="form-control" value="<?php echo $row['option2']; ?>" required>
                </div>

                <div class="mb-3">
                    <label>Option 3</label>
                    <input type="text" name="option3" class="form-control" value="<?php echo $row['option3']; ?>" required>
                </div>

                <div class="mb-3">
                    <label>Option 4</label>
                    <input type="text" name="option4" class="form-control" value="<?php echo $row['option4']; ?>" required>
                </div>

                <div class="mb-3">
                    <label>Correct Option</label>
                    <select name="correct_option" class="form-control" required>
                        <option value="1" <?php if($row['correct_option']==1) echo "selected"; ?>>Option 1</option>
                        <option value="2" <?php if($row['correct_option']==2) echo "selected"; ?>>Option 2</option>
                        <option value="3" <?php if($row['correct_option']==3) echo "selected"; ?>>Option 3</option>
                        <option value="4" <?php if($row['correct_option']==4) echo "selected"; ?>>Option 4</option>
                    </select>
                </div>

                <button type="submit" name="update" class="btn btn-success w-100">Update Question</button>

            </form>

        </div>
    </div>

    <div class="text-center mt-3">
        <a href="view_questions.php" class="btn btn-secondary">Back</a>
    </div>

</div>

</body>
</html>