<?php
session_start();
include("../../config/db.php");

if(!isset($_SESSION['role']) || $_SESSION['role'] != 'teacher'){
    die("Access Denied");
}

if(isset($_POST['upload'])){

    if($_FILES['file']['error'] == 0){

        $file = $_FILES['file']['tmp_name'];
        $handle = fopen($file, "r");

        $count = 0;

        while(($data = fgetcsv($handle, 1000, ",")) !== FALSE){

            // Skip header
            if($count == 0){
                $count++;
                continue;
            }

            // Check if row has all columns
            if(count($data) < 6){
                continue;
            }

            $question = $data[0] ?? '';
            echo $question . "<br>";
            $opt1 = $data[1] ?? '';
            $opt2 = $data[2] ?? '';
            $opt3 = $data[3] ?? '';
            $opt4 = $data[4] ?? '';
            $correct = $data[5] ?? '';

            // Skip empty rows
            if(empty($question)){
                continue;
            }

            mysqli_query($conn, "
                INSERT INTO question_bank 
                (question, option1, option2, option3, option4, correct_option)
                VALUES ('$question','$opt1','$opt2','$opt3','$opt4','$correct')
            ");
        }

        fclose($handle);
        $msg = "Questions uploaded successfully 🎉";

    } else {
        $error = "File upload failed ❌";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Upload Questions</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background: linear-gradient(135deg, #667eea, #764ba2);
    height: 100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    color:white;
}

.glass {
    background: rgba(255,255,255,0.1);
    padding:30px;
    border-radius:15px;
    width:400px;
}
</style>
</head>

<body>

<div class="glass">
    <div class="mb-3 text-end">
    <a href="../dashboard.php" class="btn btn-light">
        ⬅ Back to Dashboard
    </a>
</div>
<a href="view_questions.php" class="btn btn-warning">
    📚 Question Bank
</a>

<h3 class="text-center">📤 Upload Questions (CSV)</h3>

<?php if(isset($msg)) echo "<div class='alert alert-success'>$msg</div>"; ?>
<?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

<form method="POST" enctype="multipart/form-data">

    <input type="file" name="file" class="form-control mb-3" required>

    <button name="upload" class="btn btn-light w-100">
        Upload
    </button>

</form>

</div>

</body>
</html>