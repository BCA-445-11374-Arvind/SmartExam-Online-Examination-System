<?php
session_start();
include("../../config/db.php");

// SECURITY
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'teacher'){
    die("Access Denied");
}

// DELETE
if(isset($_GET['delete'])){
    $id = $_GET['delete'];

    mysqli_query($conn, "DELETE FROM question_bank WHERE id='$id'");

    header("Location: view_questions.php");
    exit();
}

// FETCH QUESTIONS (🔥 FIXED — NO teacher filter)
$query = "
SELECT q.*, s.subject_name 
FROM question_bank q
LEFT JOIN subjects s ON q.subject_id = s.id
ORDER BY q.id DESC
";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Question Bank</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-4">

    <div class="d-flex justify-content-between mb-3">
        <h3>Question Bank</h3>
        <div>
            <a href="add_question.php" class="btn btn-primary">+ Add Question</a>
            <a href="upload_questions.php" class="btn btn-success">📤 Upload CSV</a>
        </div>
    </div>

    <div class="card shadow">
        <div class="card-body">

            <table class="table table-bordered table-hover">
                <thead class="table-dark text-center">
                    <tr>
                        <th>ID</th>
                        <th>Subject</th>
                        <th>Question</th>
                        <th>Options</th>
                        <th>Correct</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                <?php
                if(mysqli_num_rows($result) > 0){
                    while($row = mysqli_fetch_assoc($result)){
                        echo "<tr>
                            <td>".$row['id']."</td>
                            <td>".($row['subject_name'] ?? 'N/A')."</td>
                            <td>".$row['question']."</td>
                            <td>
                                1. ".$row['option1']."<br>
                                2. ".$row['option2']."<br>
                                3. ".$row['option3']."<br>
                                4. ".$row['option4']."
                            </td>
                            <td>".$row['correct_option']."</td>
                            <td class='text-center'>
                                <a href='edit_question.php?id=".$row['id']."' class='btn btn-success btn-sm'>Edit</a>
                                <a href='?delete=".$row['id']."' class='btn btn-danger btn-sm' onclick=\"return confirm('Delete this question?')\">Delete</a>
                                <a href='../exams/add_to_exam.php?question_id=".$row['id']."' class='btn btn-warning btn-sm'>
    ➕ Add to Exam
</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center'>No Questions Found</td></tr>";
                }
                ?>
                </tbody>

            </table>

        </div>
    </div>

    <div class="text-center mt-3">
        <a href="../dashboard.php" class="btn btn-secondary">Back</a>
    </div>

</div>

</body>
</html>