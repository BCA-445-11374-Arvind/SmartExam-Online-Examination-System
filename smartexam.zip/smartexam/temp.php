<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SmartExam</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body { font-family: Arial, sans-serif; }
.hero { background: linear-gradient(to right, #0d6efd, #0b5ed7); color: white; padding: 100px 0; }
.feature-box { padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
.footer { background: #222; color: white; padding: 20px 0; }
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="#">SmartExam</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="#features">Features</a></li>
        <li class="nav-item"><a class="nav-link" href="#exams">Exams</a></li>
        <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
        <li class="nav-item"><a class="nav-link btn btn-primary text-white ms-2" href="#">Login</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero text-center">
  <div class="container">
    <h1>Welcome to SmartExam</h1>
    <p>Secure, Fast & Reliable Online Examination System</p>
    <a href="#" class="btn btn-light m-2">Start Exam</a>
    <a href="#" class="btn btn-outline-light m-2">Register</a>
  </div>
</section>

<!-- Features -->
<section id="features" class="py-5">
  <div class="container text-center">
    <h2>Features</h2>
    <div class="row mt-4">
      <div class="col-md-4"><div class="feature-box">Online Exams Anytime</div></div>
      <div class="col-md-4"><div class="feature-box">Timer Based Tests</div></div>
      <div class="col-md-4"><div class="feature-box">Instant Results</div></div>
      <div class="col-md-4 mt-3"><div class="feature-box">Secure System</div></div>
      <div class="col-md-4 mt-3"><div class="feature-box">MCQ Questions</div></div>
      <div class="col-md-4 mt-3"><div class="feature-box">Admin Dashboard</div></div>
    </div>
  </div>
</section>

<!-- Exams -->
<section id="exams" class="bg-light py-5">
  <div class="container text-center">
    <h2>Available Exams</h2>
    <div class="row mt-4">
      <div class="col-md-3"><div class="feature-box">Programming</div></div>
      <div class="col-md-3"><div class="feature-box">Aptitude</div></div>
      <div class="col-md-3"><div class="feature-box">GK</div></div>
      <div class="col-md-3"><div class="feature-box">English</div></div>
    </div>
  </div>
</section>

<!-- How it works -->
<section class="py-5 text-center">
  <div class="container">
    <h2>How It Works</h2>
    <p>1. Register → 2. Select Exam → 3. Attempt → 4. Get Result</p>
  </div>
</section>

<!-- Contact -->
<section id="contact" class="py-5">
  <div class="container text-center">
    <h2>Contact Us</h2>
    <p>Email: support@smartexam.com</p>
  </div>
</section>

<!-- Footer -->
<footer class="footer text-center">
  <p>© 2026 SmartExam. All Rights Reserved.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
